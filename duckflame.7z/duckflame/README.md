#Project duckflame @ZhiYang

Web Programming with Python and JavaScript

1. You need to install some required items in the requirements.txt.

    --pip3 install requiremnts.txt

2. You need to set the environment in bash or shell:

    --export FLASK_APP=application.py
    --export SECERET_KEY=SECERET_KEY(default)

3. Enter the command: flask run in your bash/shell at the working directory.
